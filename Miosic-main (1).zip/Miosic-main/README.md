# *اهلا بكم في سورس ريك ثون ميوزك *
# ___________________________


[قناة السورس على تلكرام](https://t.me/RICKTHONM)



[![نصب الان من هنا](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/rick1128/RICKMUSIC)

__________________________
**[RICKTHON MUSIC](https://t.me/RICKTHONM)**
**[𝘀𝗼𝘂𝗿𝗰𝗲](https://t.me/rickthon_group)**
__________________________
